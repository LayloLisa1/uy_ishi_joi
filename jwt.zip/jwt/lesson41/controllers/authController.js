const Author = require('../models/Author');

exports.createAuthor = async (req, res) => {
    const { name, bio } = req.body;
    try {
        const author = new Author({ name, bio });
        await author.save();
        res.status(201).json(author);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.getAuthors = async (req, res) => {
    try {
        const authors = await Author.find();
        res.status(200).json(authors);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.getAuthorById = async (req, res) => {
    try {
        const author = await Author.findById(req.params.id);
        if (!author) {
            return res.status(404).json({ error: 'Author not found' });
        }
        res.status(200).json(author);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.updateAuthor = async (req, res) => {
    const { name, bio } = req.body;
    try {
        let author = await Author.findById(req.params.id);
        if (!author) {
            return res.status(404).json({ error: 'Author not found' });
        }
        author.name = name || author.name;
        author.bio = bio || author.bio;
        await author.save();
        res.status(200).json(author);
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};

exports.deleteAuthor = async (req, res) => {
    try {
        const author = await Author.findById(req.params.id);
        if (!author) {
            return res.status(404).json({ error: 'Author not found' });
        }
        await author.remove();
        res.status(200).json({ msg: 'Author removed' });
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
};
